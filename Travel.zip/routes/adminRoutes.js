const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middlewares/authMiddleware');
const {
  createUser,
  getAllUsers,
  deleteUser
} = require('../controllers/admin/userAdminController');
const { getDashboardStats } = require('../controllers/adminController');
const { getAllBookings } = require('../controllers/admin/bookingAdminController');
const { getLogs } = require('../controllers/logController');
const { createPlan, getPlans } = require('../controllers/planController');

// All routes below require admin access
router.use(protect, adminOnly);

// 📌 User management
router.post('/users', createUser);
router.get('/users', getAllUsers);
router.delete('/users/:id', deleteUser);

// 📌 Plan management
router.post('/plans', createPlan);
router.get('/plans', getPlans);

// 📌 Booking overview (all users)
router.get('/bookings', getAllBookings);

// 📌 Logs (with pagination/filtering)
router.get('/logs', getLogs);

// Admin Dashboard
router.get('/dashboard', getDashboardStats);
module.exports = router;
