const paginate = async (Model, page = 1, limit = 10, filter = {}, populate = '') => {
  const skip = (page - 1) * limit;

  const [results, total] = await Promise.all([
    Model.find(filter).populate(populate).skip(skip).limit(limit),
    Model.countDocuments(filter)
  ]);

  const totalPages = Math.ceil(total / limit);

  return {
    results,
    total,
    totalPages,
    currentPage: Number(page)
  };
};

module.exports = paginate;
