const Log = require('../models/Log');
const User = require('../models/User');
const paginate = require('../utils/paginate');
// @desc    Get all logs (Admin only)
// @route   GET /api/logs
// @access  Private/Admin
const getLogs = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const data = await paginate(Log, page, limit, {}, 'user');
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch logs' });
  }
};

module.exports = {
  getLogs
};