const Booking = require('../../models/Booking');
const paginate = require('../../utils/paginate');

const getAllBookings = async (req, res) => {
  const { page = 1, limit = 10 } = req.query;
  const data = await paginate(Booking, page, limit, {}, 'plan user');
  res.json(data);
};

module.exports = { getAllBookings };
